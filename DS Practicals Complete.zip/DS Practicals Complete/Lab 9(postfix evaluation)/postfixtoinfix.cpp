#include<iostream>

#include"Stack_head.h"

#include<cstdlib>

using namespace std;

int eval_post(string str);

int main()

{	
		
	
	string str ;
	
	cout<<"Enter the expression :"<<endl;
	
	getline(cin , str);

	cout<<"Answer: "<<eval_post(str)<<endl;
	
	return 0;
}

int eval_post(string str)

{	
	
	int a,b;

	Stack <int>st1;

	int l= str.length();
	
	for(int i =0; i<l ; i++)
	
	{	

		if(str[i] == '*' || str[i] == '+' || str[i] == '-' || str[i] == '/')
		
		{	
			a = st1.topel();
				st1.pop();
				b = st1.topel();
				st1.pop();
			switch(str[i])
			{	
				
				case '*':
				{
					
					st1.push(a*b);	
								
				}
				break;
				case '+':
				{
						
					st1.push(a+b);	
							
				}
				break;
				case '-':
				{
					
					st1.push(b-a);
									
				}
				break;
				case '/':
				{
					st1.push(b/a);			
				}
				break;
				case '&':
				{
					st1.push(a&b);
				}
				break;
				
			}
		}
		else if((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z'))
		{	cout<<"Integer value required for solving an expression!! "<<endl;
			cout<<"Error "<<endl;		
		}
		else 
		{
			
			char c = str[i];
			
			int d = (int) (str[i]- '0');
			
		
			st1.push(d);
			
			
		}
		
		
		
	}	


return st1.topel();

}

