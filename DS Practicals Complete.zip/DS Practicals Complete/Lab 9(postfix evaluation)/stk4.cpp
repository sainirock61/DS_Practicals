#include<iostream>
#include<stdlib.h>
#include<string>
#define Max 100
using namespace std;

class Stack
{
	public:
	int arr[Max];
	int tos;
	Stack()
	{
		tos=0;
	}
	int push(int ele)
	{
		if(!is_full())
		{  
			arr[tos]=ele;
			tos++;
			return 0;
		}
		else
			return -1;
	}
	int pop()
	{
		if(!is_empty())
		{
			tos--;
			return -1;
		}
		else
			return 0;
	}
	bool is_full()
	{
		if(tos==Max)
			return true;
		else
			return false;
	}
	
	bool  is_empty()
	{
		if(tos==-1)
			return true;
		else
			return false;
	}	
	char topele()
	{
		return arr[tos-1];
	}
		
	void show()
	{
		cout<<"The number in the stack is ::  ";
		while(tos!=0)
		{
			if(topele()!=-1)			
				cout<<arr[tos-1]<<endl;
			tos--;
		}
	}			 
};
int main()
{
	
	Stack stk;
	string exp;
	int ele1,ele2,rel;
	cout<<"Enter the postfix expression for evaluation :: ";
	cin>>exp;
	int l=exp.length();
	stk.push(-1);
	for(int i=0;i<l;i++)
	{
		
		if(exp[i]>='0' && exp[i]<='9')
			stk.push(exp[i]-'0');
		else
		{
			ele1=stk.topele();
			stk.pop();
			ele2=stk.topele();
			stk.pop();
			if(exp[i]=='+')
				rel=ele1+ele2;
			else if(exp[i]=='-')
				rel=ele2-ele1;
			else if(exp[i]=='*')
				rel=ele2*ele1;
			else if(exp[i]=='/')
				rel=ele2/ele1;
			stk.push(rel);
		}
	}
	stk.show();
	return 0;

}

