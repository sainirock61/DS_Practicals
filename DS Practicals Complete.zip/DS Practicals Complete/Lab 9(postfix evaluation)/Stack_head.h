#include<iostream>
#include<climits>
#include<bits/stdc++.h>
#define MAX 10
using namespace std;

template <class X>

class Stack
{	
	public:
	
	X *S = new X[MAX];
	int top;
	Stack()
	{
		top = 0;	
	}
	bool isEmpty()
	{	
		if(top == 0)
		return true;
		else 
		return false; 	
	}
	bool isFull()
	{
		if(top == MAX)
		{
				
		return true;
		}		
		else 
		return false;	
	}
	bool push(X item)
	{
		if(!isFull())
		{	
			S[top] = item;
			top++;
			return true;			
		}	
		else 
			return false;
	}
	bool pop()
	{
		if(!isEmpty())
		{	
			top--;
			return true;		
		}	
		else 
			return false; 	
	}
	X topel()
	{
		if(!isEmpty())
		{
						
			return S[top-1]; 
			
		}
		else 
			return NULL;
				
	}	
};
