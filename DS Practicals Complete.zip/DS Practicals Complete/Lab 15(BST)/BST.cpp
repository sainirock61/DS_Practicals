#include<iostream>
#include<stdio.h>
using namespace std;

class BSTNode
{ 
 public:
    
    int info;
    BSTNode *left;
    BSTNode *right;
    BSTNode()
    {
        left = NULL;
        right = NULL;
    }

    BSTNode(int value)
    {
        info = value;
        left = NULL;
        right = NULL;
    }

    
};

class BST
{
public:
    BSTNode *root;
    BST()
    {
        root = NULL;
    }

    void add(int value)
    {
        BSTNode *p, *t, *r;
        r = NULL;
        t = root;
        p = new BSTNode(value);

        if (root == NULL)
        {
            root = p;
            return;
        }
        while (t != NULL)
        {
            r = t; // r pointer will be one step behind t pointer
            if (value == t->info)
                return;
            else if (value < t->info)
                t = t->left;
            else
                t = t->right;
        }
        if (p->info > r->info)
            r->right = p;
        else
           r->left = p;

}

3

void Rinorder(BSTNode *p)
{
    if (p->left != NULL)
        Rinorder(p->left);
    cout << p->info << " ";
    if (p->right != NULL)
        Rinorder(p->right);
}

void Rpreorder(BSTNode *p)
{
    cout << p->info << " ";
    if (p->left != NULL)
        Rpreorder(p->left);
    if (p->right != NULL)
        Rpreorder(p->right);
}

void Rpostorder(BSTNode *p)
{
    if (p->left != NULL)
        Rpostorder(p->left);
    if (p->right != NULL)
        Rpostorder(p->right);
    cout << p->info << " ";
}

int Height(BSTNode *p)
{
    int x,y;
    x=y=0;
    if(p==NULL)
        return 0;
    
    x=Height(p->left);
    y=Height(p->right);
    return x>y? (x+1) :(y+1);
}

BSTNode *Inprec(BSTNode *p)
{
    while(p && p->right!=NULL)
    {
        p=p->right;
    }
    return p;
}

BSTNode *Insucc(BSTNode *p)
{
    while (p && p->left != NULL)
    {
        p = p->left;
    }
    return p;
}

BSTNode *Delete(BSTNode *p, int key)
{
    BSTNode *q;
    if(p==NULL)
        return NULL;
    if(p->left==NULL && p->right == NULL)
    {
        if(p==root)
            root==NULL;
        delete p;
        return NULL;
    }

    if(key<p->info)
        p->left=Delete(p->left, key);
    else if(key>p->info)
            p->right=Delete(p->right,key);
    else
    {
        if(Height(p->left)>Height(p->right))
        {
            q=Inprec(p->left);
            p->info = q->info;
            p->left = Delete(p->left, q->info);
        }
        else
        {
            q = Insucc(p->right);
            p->info = q->info;
            p->right = Delete(p->right, q->info);
        }
        
    }
    return p;
}
BSTNode *findmin(BSTNode *root) //to find min value node
{
    if (root == NULL)
        return root; //redundant
    BSTNode *node = root;
    while (root != NULL)
    {
        if (root->left)
            node = root->left;
        root = root->left;
    }
    return node;
}

BSTNode *deleteByMerging(BSTNode *root,int key)
{
    if (root == NULL)
    {
        cout << "\ncan't delete, element not found";
        return root;
    }
    //..finding node which has the data to be deleted
    if (key < root->info)
        root->left = Delete( root->left,key);
    else if (key > root->info)
        root->right = Delete(root->right, key);

    //deletion process
    else
    {
        BSTNode *temp = root;
        if (root->left == NULL && root->right == NULL) //no child case
        {
            delete root;
            root = NULL;
        }
        else if (root->left == NULL) //one child case
        {
            root = root->right;
            delete temp;
        }
        else if (root->right == NULL) //one child case
        {
            root = root->left;
            delete temp;
        }
        else
        {
            BSTNode *node = findmin(root->right); //two children
            node->left = root->left;
            root = root->right;
            delete temp;
        }
    }
    return root;
}
};

int main()
{


    
    int choice, info;
    int pos;
    int size;
    char ch;
    BST b;
    do
    {
        cout << "\n \t\t\t\t Welcome to Linked List Menu ";
        cout << "\n 1. Adding node  \n 2. Inorder Traversal \n 3. Preorder Traversal \n 4. Postorder Traversal \n 5. Searching a node \n 6. Delete by copying \n 7. Delete By merging\n 8. Height Calculation\n ";
        cout << "\n Enter your choice : ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            cout << "\n \t\t\t\t\t Adding Node ";

            cout << "\n Enter the node info you want to insert in Binary Search Tree : ";
            cin >> info;
            b.add(info);
        }
        break;

        case 2:
        {
            cout << "\n \t\t\t\t Inorder Traversing the List\n";
            b.Rinorder(b.root);
        }
        break;

        case 3:
        {
            cout << "\n \t\t\t\t Pre-Order Traversing the List\n";
            b.Rpreorder(b.root);
        }

        break;

        case 4:
        {
            cout << "\n \t\t\t\t Post-Order Traversing the List\n";
            b.Rpostorder(b.root);
        }

        break;

        case 5:
        {
            cout << "\n \t\t\t\t Searching element in BST ";
            cout << "\n Enter the node info you want to search in tree : ";
            cin >> info;
            b.Search(info);
        }
        break;

        case 6:
        {
            cout << "\n \t\t\t\t Deleting element by copying in BST ";
            cout << "\n Enter the node info you want to delete in tree : ";
            cin >> info;
            b.Delete(b.root, info);
            cout << "\n After deleting , the tree is : ";
            b.Rinorder(b.root);
        }
        break;

        case 7:
        {
            cout << "\n \t\t\t\t Deleting element by merging in BST ";
            cout << "\n Enter the node info you want to delete in tree : ";
            cin >> info;
            b.deleteByMerging(b.root, info);
            cout<<"\n After deleting , the tree is : ";
            b.Rinorder(b.root);
        }
        break;

        case 8:
        {
            cout << "\n \t\t\t\t Finding Height of  BST ";
            int hei = b.Height(b.root);
            cout<<"\b The height is : "<<hei;
        }
        break;
        
        default:
            cout << "\n Wrong choice entered";
            break;
        }

        cout << "\n Do you want to continue(Y/y or N/n) : ";
        cin >> ch;
    } while (ch == 'Y' || ch == 'y');

    return 0;
}

   