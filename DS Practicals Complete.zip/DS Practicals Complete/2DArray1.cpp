

#include <iostream>
using namespace std;

int main(void) {
	
	int n;
	
	cout<<"Enter the number of rows: ";
	cin>>n;
	
	int** arr = new int*[n];
	// stores the number of columns
	int* col = new int[n];
	// pointer to individual arrays
	int* p;
	
	for(unsigned int i = 0; i < n; ++i) {
		int m;
		cout<<"Enter the number of columns in row "<<i + 1<<": ";
		cin>>m;
		
		// col array stoes the number of columns per row 
		*(col + i) = m;
		// 1D array of size m to store row elements
		p = new int[m];
		cout<<"Enter "<<m<<" elements of row "<<i + 1<<":\n";
		for(unsigned int j = 0; j < m; ++j) {
			cin >> *(p+j); 
		}
		// stores the address of the row just entered in the arr[] array
		*(arr + i) = p;
	}
	// ith entry of arr[] refers to ith row of 2D array, and ith entry of col[]
	// refers to no. of columns in that row
	
	cout<<"\n\ncol array:\n";
	for(unsigned int i = 0; i < n; ++i) {
		cout << *(col + i)<<" ";
	}
	
	cout << endl;
	
	cout<<"\n\nArray:\n\n";
	for(unsigned int i = 0; i < n; ++i) {
	
		p = *(arr + i);
		for(unsigned int j = 0; j < *(col + i); ++j) {
			cout << *(p + j) <<" ";
		}
		cout << endl;
	}
	
	delete[] arr;
	delete[] col;
	delete[] p;
	return 0;
}
	

