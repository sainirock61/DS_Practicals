#include<iostream>
#include<bits/stdc++.h>
using namespace std;
#define MAX 10
class Stack
{
int stack[MAX];
int top;      //top of the element of the stack

public:


Stack()
{
 top=0;
}

bool push(int element)
{
 	if(!isFull())
 	{
		
  		stack[top]=element;
  		top++;

		return true;
 	}
	else
		return false;
}

bool pop()
{
	if(!isEmpty())
	{
		top--;
		return true;
	}
	else
		return false;
}

int topel()
{
	if(!isEmpty())
			return stack[top-1];
					
	else
		return -2;
}


bool isFull()
{
 	if( top == MAX)
		return true;
 	else
		return false;
}

bool isEmpty()
{
 	if (top==0)
		return true;
 	else
		return false;
}

};

int main()
{
	Stack stack1;
	char c;
	int element;

	cout << "\tImplementation of stack\n";
 do{
	cout << "Operations available on stack:\n";
	cout << "1. Push an element in a stack\n";
	cout << "2. Pop an element from a stack\n";
	cout << "3. Show the element at the top\n";
	cout << "\nEnter your choice :";
	int choice;
		cin>>choice;
	switch( choice )
	{
		case 1 :
				cout << "Enter the element to be pushed :";
				//int element;
				cin>>element;


				if( stack1.push(element) )
				{
					cout << "\nDone!";
				}
				else
					cout << "\nStack Overflow";
				break;

		case 2 :	
				element=stack1.topel();

				if( stack1.pop() != -1)
				{
					cout << "Popping out element " << element<< '.';
					cout << "Done!";
				}
				else
					cout << "\nStack Underflow";
				break;

		case 3 :
				if( stack1.topel() != -1)
					cout << "The element on the top is " << stack1.topel() ;
				else
						cout << "Stack Underflow";
				break;
	}//switch

	cout << "\n\nAnother operation? (y/n) :";
		cin >> c;

 }  while( c=='y' || c=='Y');

	return 0;
}








