#include<iostream>
using namespace std;
void display(int arr[],int size)
{
	for(int i=0;i<size;i++)
		cout<<arr[i]<<"   ";
	cout<<"\n";
	
}
void swap(int *a, int *b)  
{  
    int temp = *a;  
    *a = *b;  
    *b = temp;  
}  
void selectionsort(int arr[],int size)
{
	for (int i = 0; i < size-1; i++)  
    	{    
        	int flag = i;  
        	for (int j = i+1; j < size; j++)  
        		if (arr[j] < arr[flag])  
            			flag = j;  
        	swap(&arr[flag], &arr[i]);  
   	}  
	
}

void bubblesort(int arr[], int size)  
{  
    int i, j;  
    for (i = 0; i < size-1; i++)        
    	for (j = 0; j < size-i-1; j++)  
        if (arr[j] > arr[j+1])  
            swap(&arr[j], &arr[j+1]);  
}  


void insertionsort(int arr[], int size)  
{  
    int i, ele, j;  
    for (i = 1; i < size; i++) 
    {  
        ele = arr[i];  
        j = i - 1;  
        while (j >= 0 && arr[j] > ele) 
        {  
            arr[j + 1] = arr[j];  
            j = j - 1;  
        }  
        arr[j + 1] = ele;  
    }  
}  

int partition (int arr[], int low, int high)  
{  
    int pivot = arr[high];   
    int i = (low - 1);   
  
    for (int j = low; j <= high - 1; j++)  
    {    
        if (arr[j] < pivot)  
        {  
            i++;   
            swap(&arr[i], &arr[j]);  
        }  
    }  
    swap(&arr[i + 1], &arr[high]);  
    return (i + 1);  
}  

void quicksort(int arr[], int low, int high)  
{  
    if (low < high)  
    {  
        int pi = partition(arr, low, high);  
        quicksort(arr, low, pi - 1);  
        quicksort(arr, pi + 1, high);  
    }  
}

void merge(int arr[], int l, int m, int r)
{
	int i, j, k;
	int n1 = m - l + 1;
	int n2 = r - m;

	int L[n1], R[n2];

	for (i = 0; i < n1; i++)
		L[i] = arr[l + i];
	for (j = 0; j < n2; j++)
		R[j] = arr[m + 1 + j];

	i = 0;
	j = 0;
	k = l;
	while (i < n1 && j < n2)
	{
		if (L[i] <= R[j])
			arr[k++] = L[i++];

		else
			arr[k++] = R[j++];
	}

	while (i < n1)
	{
		arr[k++] = L[i++];
	}

	while (j < n2)
	{
		arr[k++] = R[j++];
	}
}

void mergeSort(int arr[], int l, int r)
{
	if (l < r)
	{

		int m = l + (r - l) / 2;

		mergeSort(arr, l, m);
		mergeSort(arr, m + 1, r);

		merge(arr, l, m, r);
	}
}
int main()
{
	int ch,a[50],n;
	cout<<"                   MAIN MENU                 ";
	cout<<"\n1.Enter 1 for Selection Sort....";
	cout<<"\n2.Enter 2 for Bubble Sort....";
	cout<<"\n3.Enter 3 for Insertion Sort....";
	cout<<"\n4.Enter 4 for Quick Sort....";
	cout<<"\n5.Enter 5 for Merge Sort....";
	cout<<"\nEnter your choice....";
	cin>>ch;
	switch(ch)
	{
		case 1:
			cout<<"\nEnter the number of elements in the sequence...";
			cin>>n;
			cout<<"\nEnter the sequence to be sorted...";
			for(int i=0;i<n;i++)
			{
				cin>>a[i];
			}
			cout<<"\nThe sequence before sorting is....";
			display(a,n);
			selectionsort(a,n);
			cout<<"\nThe sequence after sorting is....";
			display(a,n);
			break;
		case 2:
			cout<<"\nEnter the number of elements in the sequence...";
			cin>>n;
			cout<<"\nEnter the sequence to be sorted...";
			for(int i=0;i<n;i++)
			{
				cin>>a[i];
			}
			cout<<"\nThe sequence before sorting is....";
			display(a,n);
			bubblesort(a,n);
			cout<<"\nThe sequence after sorting is....";
			display(a,n);
			break;
		case 3:
			cout<<"\nEnter the number of elements in the sequence...";
			cin>>n;
			cout<<"\nEnter the sequence to be sorted...";
			for(int i=0;i<n;i++)
			{
				cin>>a[i];
			}
			cout<<"\nThe sequence before sorting is....";
			display(a,n);
			insertionsort(a,n);
			cout<<"\nThe sequence after sorting is....";
			display(a,n);
			break;
		case 4:
			cout<<"\nEnter the number of elements in the sequence...";
			cin>>n;
			cout<<"\nEnter the sequence to be sorted...";
			for(int i=0;i<n;i++)
			{
				cin>>a[i];
			}
			cout<<"\nThe sequence before sorting is....";
			display(a,n);
			quicksort(a,0,n-1);
			cout<<"\nThe sequence after sorting is....";
			display(a,n);
			break;
		case 5:
			cout<<"\nEnter the number of elements in the sequence...";
			cin>>n;
			cout<<"\nEnter the sequence to be sorted...";
			for(int i=0;i<n;i++)
			{
				cin>>a[i];
			}
			cout<<"\nThe sequence before sorting is....";
			display(a,n);
			mergeSort(a,0,n-1);
			cout<<"\nThe sequence after sorting is....";
			display(a,n);
			break;
			
	}
	return 0;
}

