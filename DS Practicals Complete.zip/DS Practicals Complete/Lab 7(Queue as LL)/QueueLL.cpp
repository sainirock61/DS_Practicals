#include<iostream>
using namespace std;
class Node
{
public:
    int info;
    Node *next; // this points to the address of the next node
    Node()
    {
        info = 0;
        next = NULL;
    }

    Node(int value)
    {
        info = value;
        next = NULL;
    }
};

class Queue
{
public:
    Node *front;
    Node *rear;

    Queue()
    {
        front = NULL;
        rear = NULL;
    }

    void enqueue(int value)  // Add at tail
    {
    Node *t = new Node(value);

    if(t==NULL)
        cout<<"\n Queue is Full ";
    if(front==NULL)
        front=rear=t;

    else
    {
        Node *temp = rear;
        temp->next = t;
        rear = t;
    }

    }

    void dequeue() // Delete at head
    {
        Node *t;
        if(front==NULL)
            cout<<"\n Queue is Empty ";
        if (front == rear)
        {
            delete front;
            front = rear = NULL;
        }
        else
        {
            t=front;
            front=front->next;
            delete t;
        }
        
    }

    void Display()
    {
        Node *p=front;
        while(p)
        {
            cout<<p->info<<" ";
            p=p->next;
        }
    }

};

int main()
{
    int choice, info;
    int pos;
    int size;
    char ch;
    Queue q;
    do
    {
        cout << "\n \t\t\t\t Welcome to Queue as a Linked list Menu ";
        cout << "\n 1. Adding node  \n 2. Deleting Node \n 3. Traversing the queue \n ";
        cout << "\n Enter your choice : ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            cout << "\n \t\t\t\t\t Adding Node ";

            cout << "\n Enter the node info you want to insert in Queue : ";
            cin >> info;
            q.enqueue(info);
        }
        break;

        case 2:
        {
            cout << "\n \t\t\t\t\t  Deleting Node";
            q.dequeue();
        }
        break;

        case 3:
        {
            cout << "\n \t\t\t\t Traversing the Queue \n";
            q.Display();
        }

        break;

        default:
            cout << "\n Wrong choice entered";
        }

        cout << "\n Do you want to continue(Y/y or N/n) : ";
        cin >> ch;
    } while (ch == 'Y' || ch == 'y');

    return 0;

}