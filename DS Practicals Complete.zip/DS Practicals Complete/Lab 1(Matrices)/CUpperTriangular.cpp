//UpperTriangular Matrix using Column major Method

#include <iostream>
using namespace std;
class UpperTri
{
private:
    int *A;
    int n;

public:
    UpperTri()
    {
        n = 2;
        A = new int[2 * (2 + 1) / 2];
    }
    UpperTri(int n)
    {
        this->n = n;
        A = new int[n * (n + 1) / 2];
    }
    ~UpperTri()
    {
        delete[] A;
    }
    void Store(int i, int j, int x);
    int Retrieve(int i, int j);
    void Display();
    int GetDimension()
    {
        return n;
    }
};

void UpperTri::Store(int i, int j, int x)
{
    if (i <= j)
        A[j*(j-1)/2 + (i-1)] = x;
}
int UpperTri::Retrieve(int i, int j)
{
    if (i <= j)
        return A[j * (j - 1) / 2 + (i - 1)];
    return 0;
}
void UpperTri::Display()
{

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (i <= j)
                cout << A[j * (j - 1) / 2 + (i - 1)] << " ";
            else
                cout << "0 ";
        }
        cout << endl;
    }
}

int main()
{
    int d;
    cout << "Enter Dimensions";
    cin >> d;
    UpperTri um(d);
    int x;
    cout << "Enter All Elements";
    for (int i = 1; i <= d; i++)
    {
        for (int j = 1; j <= d; j++)
        {
            cin >> x;
            um.Store(i, j, x);
        }
    }
    um.Display();
    return 0;
}