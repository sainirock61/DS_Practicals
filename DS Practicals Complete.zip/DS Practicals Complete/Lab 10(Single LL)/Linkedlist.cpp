#include <iostream>
using namespace std;
void AddAtHead(int info) ;
void AddAtTail(int info) ;
void DelAtHead() ;
void DelAtTail() ;
void Add_at_Nth_pos(int n, int info) ;
void Delete_at_Nth_pos(int index) ;
void Reverse() ;
void Delete_Middle() ;
void Search(int element);
void traverse() ;
class SLLNode
{
public:
    int info;
    SLLNode *next; // this points to the address of the next node

    SLLNode()
    {
        info = 0;
        next = NULL;
    }

    SLLNode(int infoo)
    {
        info = infoo;
        next = NULL;
    }
};

class SLList
{
public:
    SLLNode *head;
    SLLNode *tail;

    SLList() 
    {
        head = NULL;
        tail = NULL;
    }

    void AddAtHead(int info)
    {
        if (head == NULL)
        {
            SLLNode *N = new SLLNode(info);
            head = N;
            tail = N;
        }
        else
        {
            SLLNode *N = new SLLNode(info);
            N->next = head;
            head = N;
        }
    }

    void AddAtTail(int info)
    {
        if (tail == NULL)
        {
            SLLNode *N = new SLLNode(info);
            head = N;
            tail = N;
        }
        else
        {
            SLLNode *N = new SLLNode(info);
            SLLNode *temp = tail;
            temp->next = N;
            tail = N;
        }
    }

    void DelAtHead()
    {
        SLLNode * temp;
        if(head==NULL)
            return;
        else if(head==tail)
        {
            delete head;
            delete tail;
            head = NULL;
        }
        else
        {
            
            temp=head;
            head=head->next;
            delete temp;
        }
        
    }

    void Odd()
    {
        SLLNode *p=head;
        int s=0;
        while(p!=NULL)
        {
            if((p->info)%2 !=0)
                s+=p->info;
            p=p->next;
        }
        cout<<s;
    }

    void DelAtTail()
    {
        SLLNode *temp=head;
        if(tail==NULL)
        return;
        else if(head==tail)
        {
             delete head;
             delete tail;
             head=NULL;
        }
         else
        {
             while(temp->next!=tail)
                temp=temp->next;
             tail=temp;
             tail->next=NULL;
             temp=temp->next;

             delete temp;
        }
    }

    void Add_at_Nth_pos(int n, int info)
    {
        SLLNode *p = head;
        SLLNode *temp = new SLLNode(info);
        for (int i=0;i<n-1 && p!=NULL;i++)
        {
            p=p->next;
        }
         if(p!=NULL)
         {
         temp->next= p->next;
         p->next=temp;
         }

    }

    void Delete_at_Nth_pos(int index)
    {
        SLLNode *p=head;
        SLLNode *q=NULL; //this pointer will be one position before the pointer p
        for(int i=0;i<index-1 && p!=NULL; i++)
        {
            q=p;  
            p=p->next;
        }

        if(p)
        {
            q->next=p->next;
            delete p;
        }

    }

    void Delete_Middle()
    {
        SLLNode *temp,*p,*q;
        p=q=head;
        temp=NULL;
        while(q!=NULL)
        {
            q=q->next;
            if(q)
                q=q->next;
            if(q)
            {
                temp=p;
                p=p->next;
            }
            
        }
        temp->next=p->next;
        delete p;
    }
    void Reverse()
    {
        SLLNode *p,*q,*r;
        p=head;
        q=r=NULL;

        while(p!=NULL)
        {
            r=q;
            q=p;
            p=p->next;
            q->next=r;   //  reversing the next pointer link
        }

        head=q; //last element become head
    }

        void Search(int element)
    {
        int cnt=0;
        int res=0;
        if(head==NULL)
        {
            cout<<"\n List is empty !!";
        }

        SLLNode *N = head;

        while (N != NULL)
        {
            if (N->info == element)
            {
                res=1;
                break;
            }
            else
            {
                N = N->next;
                cnt++;
            }
        }
        if(res==0)
        cout<<"\n Element not found in the list !!";
        else
        cout<<"\n Kuddos!!! Element found at index : "<<cnt<<" at address: "<<&(N->next);
    }

    void traverse()
    {
        SLLNode *N;
        N = head;
        while (N != NULL)
        {
            cout << N->info;
            cout << endl;
            N = N->next;
        }
    }
};

int main()
{   
    int choice, info;
    int pos;
    int size;
    char ch;
    SLList l;
    do
    {
    cout<<"\n \t\t\t\t Welcome to Linked List Menu ";
    cout<<"\n 1. Adding node at head \n 2. Adding node at tail \n 3. Searching a particular node \n 4. Deleting node from head \n 5. Deleting node from tail \n 6. Traversing the list  \n 7. Adding Node at Nth position \n 8. Deleting Node at Nth position \n 9. Reversing the linked list \n 10. Deleting the middle element";
    cout<<"\n Enter your choice : ";
    cin>>choice;


    switch(choice)
    {
        case 1 :
        {  
            cout<<"\n \t\t\t\t\t Adding Node at Head ";
           
                cout << "\n Enter the node info you want to insert in Linked list : ";
                cin >> info;
                l.AddAtHead(info);
        }
        break;

        case 2:
        {
            cout << "\n \t\t\t\t Adding Node at Tail ";
            cout << "\n Enter the node info you want to insert in Linked list : ";
            cin >> info;
            l.AddAtTail(info);  
        }
            break;

        case 3:
        {
            cout << "\n \t\t\t\t Searching element in Linked List ";
            cout << "\n Enter the node info you want to search in Linked list : ";
            cin >> info;
            l.Search(info);
        }
        break;

        case 4:
        {
            cout << "\n \t\t\t\t Deleting Node at Head ";
    
            l.DelAtHead();
        }
        break;

        case 5:
        {
            cout << "\n \t\t\t\t Deleting Node at Tail ";
        
            l.DelAtTail();
        }
        break;

        case 6:
        {
            cout << "\n \t\t\t\t Traversing the List\n";
            l.traverse();
        }
        break;

        case 7:
        {
            cout<<"\n Enter the position on which the node is to be inserted : ";
            cin>>pos;
            cout << "\n Enter the node info you want to insert in Linked list : ";
            cin >> info;
            l.Add_at_Nth_pos(pos,info);
        
        }
        break;

        case 8:
        {
            cout << "\n Enter the position on which the node is to be deleted : ";
            cin >> pos;
            l.Delete_at_Nth_pos(pos);
        }
        break;

        case 9 :
        {
            cout<<"\n The Reversed linked list is shown below : ";
            l.Reverse();
            l.traverse();
        }
        break;

        case 10:
        {
            cout<<"\n Deleting Middle element";
            cout<<endl;
            l.Delete_Middle();
            l.traverse();
        }
        break;
        
        default : cout<<"\n Wrong choice entered";

    }
   
    cout<<"\n Do you want to continue(Y/y or N/n) : ";
    cin>>ch;
    }while(ch=='Y'||ch=='y');
    
    return 0;
}