#include "Stack_head.h"

using namespace std; 
  
string inf_post(string s);

int prec(char c) 
{ 
    if(c == '^') 
    return 3; 
    else if(c == '*' || c == '/') 
    return 2; 
    else if(c == '+' || c == '-') 
    return 1; 
    else
    return -1; 
} 
  

string inf_Post(string s) 
{ 
    Stack <char> st; 
   
    int l = s.length(); 
    string str; 
    for(int i = 0; i < l; i++) 
    { 
    
        if((s[i] >= 'a' && s[i] <= 'z')||(s[i] >= 'A' && s[i] <= 'Z') || (s[i]  >= '1' && s[i] <= '9') )
        str = str + s[i]; 
  
      
        else if(s[i] == '(') 
          
        st.push('('); 
          

        else if(s[i] == ')') 
        { 
            while(st.topel() != '(') 
            { 
               
		 str = str + st.topel();
                st.pop(); 
               
            } 
            if(st.topel() == '(') 
            { 
               
                st.pop(); 
            } 
        } 
          
        
        else{ 
            while(prec(s[i]) <= prec(st.topel())) 
            { 
               
		 str = str+ st.topel(); 
                st.pop(); 
               
            } 
            st.push(s[i]); 
        } 
  
    } 
  
    while(!st.isEmpty()) 
    { 
	 str = str + st.topel(); 
        st.pop(); 
       
    } 
      
    return str;
  
} 
   
int main() 
{ 
    string str1;
	cout<<"Enter the expression: ";
	getline(cin,str1); 
	
		cout<<inf_Post(str1); 
    
		
    return 0; 
} 

