#include<iostream>
using namespace std;
int main()
{
 int row;
 int col;
 cout<<"Enter the number of rows";
 cin>>row;
 int **p=new int*[row];      
 cout<<"Enter the number of columns";
 cin>>col;
 for(int k=0;k<row;k++)
 {
  *(p+k)=new int [col];
 }
 cout<<"Enter the number of elements:"<<endl;
 for(int i=0;i<row;i++)
 {
  for(int j=0;j<col;j++)
  {
   cin>>*(*(p+i)+j);
  }
 }  
 cout<<"\n";
 cout<<"output:\n\n";
 for(int i=0;i<row;i++)
 {
  for(int j=0;j<col;j++)
  {
   cout<<*(*(p+i)+j);
   cout<<" ";
  }
  cout<<"\n";    
 }
}  
