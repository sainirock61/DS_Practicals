#include<iostream>
using namespace std;
class SLLNode
{
public:
    int power;
    int info;
    SLLNode *next; // this points to the address of the next node

    SLLNode()
    {
        info = 0;
        power =-1;
        next = NULL;
    }

    SLLNode(int p,int i)
    {
        info = i;
        power = p;
        next = NULL;
    }
};

class SLList
{
public:
    SLLNode *head;
    SLLNode *tail;

    SLList() 
    {
        head = NULL;
        tail = NULL;
    }

    void AddAtTail(int power, int info)
    {
        if (tail == NULL)
        {
            SLLNode *N = new SLLNode(power,info);
            head = N;
            tail = N;
        }
        else
        {
            SLLNode *N = new SLLNode(power,info);
            SLLNode *temp=tail;
            temp->next = N;
            tail = N;
        }
    }

    void traverse()
    {
        SLLNode *N;
        N = head;
        while (N != NULL)
        {
            cout << N->info <<"x^"<<N->power;
            N = N->next;
            cout<<endl;
           // if(N->next !=NULL)
              // cout<<" + ";
        }
    }


    SLList *add(SLList *l1 , SLList *l2)
    {
        SLList * l3;
        l3=new SLList();
        SLLNode * p = l1->head;
        SLLNode * q = l2->head;
        
        while(p && q)
        {
            SLLNode *r = new SLLNode();
            // If power of 1st polynomial is greater then 2nd, then store 1st as it is and move its pointer
            if (p->power > q->power)
            {
                r->power = p->power;
                r->info = p->info;
                l3->AddAtTail(r->power,r->info);
                p = p->next;
            }
            // If power of 2nd polynomial is greater then 1st, then store 2nd as it is and move its pointer
            else if (p->power < q->power)
            {
                r->power = q->power;
                r->info = q->info;
                l3->AddAtTail(r->power, r->info);
                q = q->next;
            }
            // If power of both polynomials is same , then add their coefficients
            else
            {
                r->power = p->power;
                r->info = p->info + q->info;
                l3->AddAtTail(r->power, r->info);
                p=p->next;
                q=q->next;
            }     
        }

        while (p || q)
        {
            SLLNode *r = new SLLNode();
            if (p!=NULL)
            {
                r->power = p->power;
                r->info = p->info;
                l3->AddAtTail(r->power, r->info);
                p = p->next;
            }

            else if (q!=NULL)
            {
                r->power = q->power;
                r->info = q->info;
                l3->AddAtTail(r->power, r->info);
                q = q->next;
            }
       }
         return l3;
    }
};

int main()

{

    SLList   *l1,*l2,*l3;
    l1=new SLList();
    l2=new SLList();
    int info,power;
    char ch;
    //inputing first polynomial
    cout<< "            Enter the first polynomial          ";
    do
    {
        cout << "\n Enter the power of the node you want to insert in Linked list I: ";
        cin >> power;
        cout << "\n Enter the node info you want to insert in Linked list II : ";
        cin >> info;
        l1->AddAtTail(power,info);
        l1->traverse();
        cout<<endl;
        cout << "\n Do you want to continue(Y/y or N/n) : ";
        cin >> ch;
    } while (ch == 'Y' || ch == 'y');

    //inputing second polynomial
    cout<< "            Enter the second polynomial          ";
    do
    {
        cout << "\n Enter the power of the node you want to insert in Linked list II: ";
        cin >> power;
        cout << "\n Enter the node info you want to insert in Linked list II : ";
        cin >> info;

        l2->AddAtTail(power, info);
        l2->traverse();
        cout << endl;

        cout << "\n Do you want to continue(Y/y or N/n) : ";
        cin >> ch;
    } while (ch == 'Y' || ch == 'y');

    l3=new SLList();
    l3= l3->add(l1,l2);
    l3->traverse();

    return 0;
}

