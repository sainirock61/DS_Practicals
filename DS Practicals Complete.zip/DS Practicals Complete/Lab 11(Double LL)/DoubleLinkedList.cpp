#include <iostream>
using namespace std;

void AddAtHead(int info);
void AddAtTail(int info);
void DeleteFromHead() ;
void DeleteFromTail() ;
void Add_Before_N_Pos(int n, int info);
void Add_After_N_Pos(int n, int info) ;
void Delete_After_N_Pos(int n) ;
void Search(int element);
void traverse_forward();
void traverse_backward();


class DLLNode
{
public:
    int info;
    DLLNode *next; // this points to the address of the next node
    DLLNode *prev; // this points to the address of the previous node

    DLLNode()
    {
        info = 0;
        next = NULL;
        prev = NULL;
    }

    DLLNode(int infoo)
    {
        info = infoo;
        next = NULL;
        prev = NULL;
    }
};


class DLList
{
public:
    DLLNode *head;
    DLLNode *tail;

    DLList()
    {
        head = NULL;
        tail = NULL;
    }
 
 // methods of the class will be declared here

    void AddAtHead(int info)
    {
        if (head == NULL)
        {
            DLLNode *p = new DLLNode(info);
            head = p;
            tail = p;
        }
        else
        {
            DLLNode *p = new DLLNode(info);
            p->next = head;
            head->prev = p;
            head = p;
        }
    }

    void AddAtTail(int info)
    {
        if (tail == NULL)
        {
            DLLNode *p = new DLLNode(info);
            head = p;
            tail = p;
        }
        else
        {
            DLLNode *p = new DLLNode(info);
            tail->next = p;
            p->prev = tail;
            tail=p;
        }
    }


    void DeleteFromHead()
    {
        if(head==NULL)
            return;
        else if(head==tail)
            {
                delete head;
                head=NULL;
                tail=NULL;
            }
        else
        {
            DLLNode *temp=head;
            head=head->next;
            head->prev=NULL;
            delete temp;
        }
        
    }

    void DeleteFromTail()
    {
        if(tail==NULL)
            return;
        else if(head==tail)
        {
            delete tail;
            head==NULL;
            tail==NULL;
        }
        else
        {
            DLLNode *temp = tail;
            tail=tail->prev;
            tail->next = NULL;
            delete temp;
        }
    }

    void Add_Before_N_Pos(int n, int info)
    {
        int count =0;
        DLLNode *p=head;

        while(p!=NULL && count<n-1)
        {
            p = p->next;
            count++;
        }

        if (p == NULL)
            return;
        else if (count == n-1)
        {
            DLLNode *N = new DLLNode(info);
            N->next = p->next;
            p->next->prev = N;
            p->next = N;
            N->prev = p;
        }
    }


    void Add_After_N_Pos(int n, int info)
    {
        int count = 0;
        DLLNode *p = head;

        while (p != NULL && count <n)
        {
            p = p->next;
            count++;
        }

        if (p == NULL)
            return;
    
        if(count == n)
        {
            DLLNode *N = new DLLNode(info);
            N->next = p->next;
            p->next->prev = N;
            p->next = N;
            N->prev = p;
        }
    }

    void Delete_After_N_Pos(int n)
    {
        int count = 0;
        DLLNode *p = head;

        while (p != NULL && count < n)
        {
            p = p->next;
            count++;
        }

        if (p == NULL)
            return;
        else if(count==n)
        {
            if(p->next->next!=NULL)
            {
            DLLNode *temp = p->next;
            p->next->next->prev = p;
            p->next=p->next->next;
            delete temp;
        }
        else
        {
            DLLNode *temp = tail;
            tail = tail->prev;
            tail->next = NULL;
            delete temp;
        }
        }

    }

        void Search(int element)
        {
            int cnt = 0;
            int res = 0;
            if (head == NULL)
            {
                cout << "\n List is empty !!";
            }

            DLLNode *N = head;

            while (N != NULL)
            {
                if (N->info == element)
                {
                    res = 1;
                    break;
                }
                else
                {
                    N = N->next;
                    cnt++;
                }
            }
            if (res == 0)
                cout << "\n Element not found in the list !!";
            else
                cout << "\n Kuddos!!! Element found at index : " << cnt << " at address: " << &(N->next);
        }

        void traverse_forward()
        {
            DLLNode *p = head;
            while (p != NULL)
            {
                cout << p->info;
                cout << " ";
                p = p->next;
            }
        }

        void traverse_backward()
        {
            DLLNode *p = tail;
            while (p != NULL)
            {
                cout << p->info;
                cout << " ";
                p = p->prev;
            }
        }

};


int main()
{
    DLList l;
    l.AddAtHead(10);
    l.AddAtHead(15);
    l.AddAtTail(20);
    l.AddAtHead(50);
    l.traverse_forward();
cout<<endl;
    l.Delete_After_N_Pos(2);
    l.traverse_forward();

   /* l.traverse_backward(); //20 10 15
    cout<<endl;
    l.Add_Before_N_Pos(1,45);
    l.traverse_forward(); 
    cout<<endl;
    l.Add_After_N_Pos(2,60);
    l.traverse_forward();
cout<<endl;
    l.DeleteFromHead();
    l.traverse_forward();

    l.DeleteFromTail();
    cout<<endl;
    l.traverse_forward();*/

    return 0;
}