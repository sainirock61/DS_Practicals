#include<iostream>

#include<climits>

#include<bits/stdc++.h>

#include "Stack_head.h"

#define MAX 10

using namespace std;

bool paren(string str);

bool paren(string str , Stack <char>st1)
{
	
	char ch;
	for(int i = 0 ;i<str.length() ; i++)
	
	{
		if(str[i] == '{' || str[i] == '[' || str[i] == '(')
		
		{
		
			st1.push(str[i]);
			
		}
		
			
				
				if(str[i] == '}')
				{	
					
					if(st1.topel() == '{')
					{
						st1.pop();
									
					}
					else if(st1.isEmpty())
					return false;
				}
		
				else if(str[i] == ')')

				{	
					
					if(st1.topel() == '(')
					{
						st1.pop();
											
					}
					else if(st1.isEmpty())
					return false;
				}

				else if(str[i] == ']')
				
				{	
					
					if(st1.topel() == '[')
					{					
						st1.pop();
										
					}
					else if(st1.isEmpty())
					return false;
				}
	

	}
		return (st1.isEmpty());
		
		
		
}

int main()

{

	Stack <char>st1;
	
	string str; 
	
	char ch;
	
	printf("Enter the expression: \n");
	
	getline(cin , str);
	
	if(paren(str , st1))
		
		cout<<" Expression is valid !! ";
	
	else

		cout<<" Expression is invalid !! "<<endl;	
			
	exit(0);
	
	return 0;

}

