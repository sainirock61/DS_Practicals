#include<iostream>
#include<climits>
#include<bits/stdc++.h>
#include "Stack_head.h"
#define MAX 20
using namespace std;

int main()
{	
	int n;
	int m;
	Stack st1;
	Stack st2;
	Stack st3;
	string str1;
	string str2;

	cout<<"Enter the no in stack 1: ";
	getline(cin,str1);
	
	for(int i = 0 ; i<str1.length(); i++)
	{	
		st1.push(str1[i]-'0');  //pushing an element in first stack
	}
	

	cout<<"Enter the no in stack 2: ";

	getline(cin,str2);
	
	for(int j =0 ; j<str2.length() ; j++)
	{	

		st2.push(str2[j] - '0');	//pushing an element in stack 2	
		
	}
	
	int carry = 0;

	while( !st1.isEmpty() && !st2.isEmpty()) // run the loop until one of the two stack is empty

	{		
		if((st1.topel()+st2.topel()+carry) > 9) 

		{	
			int s = ((carry  + st1.topel() + st2.topel())%10); // adding top elements of the stacks
			
			carry = (st1.topel() + st2.topel()+ carry)/10;
			
			st3.push(s);
					
		}		

		else 
		{	
			st3.push(carry + st1.topel() + st2.topel());
			carry = 0;	
		}
		st1.pop();
		st2.pop();
	}	

	
	if(st1.isEmpty()) {// check which stack is full
		while(!st2.isEmpty())
		{		
			if((st2.topel()+carry)>9)
			{
				int s = (carry + st2.topel())%10;
		
				carry=(carry+st2.topel())/10;
				
				st3.push(s);
			}
			else 
			{	st3.push(carry+st2.topel());
			
				carry = 0;			
			}	
				st2.pop();
		}	
	}

	else if (st2.isEmpty()) 
	{
		while(!st1.isEmpty())
		{	
			if((st1.topel()+carry)>9)
			{
				int s = (carry + st1.topel())%10;
		
				carry=(carry+st1.topel())/10;
				
				st3.push(s);
			}
			else 
				{
					st3.push(carry+st1.topel());
					carry =0;
				}	
				st1.pop();
		}
	}
	st3.push(carry);
	
	
 	cout<<"sum is : "<<endl;
		
	while(!st3.isEmpty())
	{
		cout<<st3.topel();
		st3.pop();
	}
	
	cout<<endl;
	return 0;
}

