#include<iostream>
#include<stdlib.h>
#define Max 100
using namespace std;

class Stack
{
	public:
	int arr[Max];
	int tos;
	Stack()
	{
		tos=0;
	}
	int push(int ele)
	{
		if(!is_full())
		{  
			arr[tos]=ele;
			tos++;
			return 0;
		}
		else
			return -1;
	}
	int pop()
	{
		if(!is_empty())
		{
			tos--;
			return -1;
		}
		else
			return 0;
	}
	bool is_full()
	{
		if(tos==Max)
			return true;
		else
			return false;
	}
	
	bool  is_empty()
	{
		if(tos==-1)
			return true;
		else
			return false;
	}	
	int topele()
	{
		return arr[tos-1];
	}
		
	void show()
	{
		cout<<"The number in the stack is : ";
		while(tos!=0)
		{
			cout<<arr[tos-1];
			tos--;
		}
	}			 
};
int main()
{
	Stack stk1;
	Stack stk2;
	Stack result;
	int n=0;
	cout<<"Enter the number in the first stack....(to end enter -1)...";
	
	while(n!=-1)
	{
		cin>>n;
		if(n!=-1)		
			stk1.push(n);
	}
	cout<<"Enter the number in the second stack....(to end enter -1)...";
	n=0;	
	while(n!=-1)
	{
		cin>>n;
		if(n!=-1)		
			stk2.push(n);
	}
	int carry=0;
	int temp,cal;
	while(!stk1.is_empty()&&!stk2.is_empty())
	{
		temp=stk1.topele()+stk2.topele()+carry;
		carry=temp/10;
		cal=temp%10;
		result.push(cal);
		stk1.tos--;
		stk2.tos--;
	}
	while(!stk1.is_empty())
	{
		temp=stk1.topele()+carry;
		carry=temp/10;
		cal=temp%10;
		result.push(cal);
		stk1.tos--;
	}
	while(!stk2.is_empty())
	{
		temp=stk2.topele()+carry;
		carry=temp/10;
		cal=temp%10;
		result.push(cal);
		stk2.tos--;
	}
	result.show();		 
	return 0;
}
