#include<iostream>
using namespace std;

//insertion
//deletion
//search
//Reverse
template<typename T>
class CLLNode{
public:
     CLLNode * next;
     T info ;
     CLLNode(){
          next = NULL;
     }
     CLLNode(T info){
          next = NULL;
          this->info = info;
     }
};
template<typename T>
class CLList{
public:
     CLLNode<T> * head;
     CLLNode<T> * tail;
     CLList(){
          head = NULL;
          tail = NULL;
     }
     void addAtHead(T data){
          CLLNode<T> * p = new CLLNode<T>(data);
          if(head == NULL){
               head = p;
               tail = p;
               tail->next = head;
          }
          else{
               p->next = head;
               tail->next = p;
               head = p ;
          }

     }
     void deletefromhead(){
          if(head == NULL)
               return;
          else if(head == tail){
               delete head;
               head = NULL;
               tail = NULL;
          }
          else{
               CLLNode<T> * temp = head;
               tail->next = head->next;
               head = head->next;
               delete temp;
          }
     }

     CLLNode<T> * search(T el){
          if(head == NULL)
               return head;
          else{
               CLLNode<T> * p = head;
               do{
                    if(p->info == el){
                         return p;
                    }
                    p = p->next;
               }while(p != head);

               return NULL;
          }
     }

     //do reverse 
     void reverse(){
          if(head == NULL)
               return;
          CLLNode<T> * p,*q,*temp;
          q = tail;
          p = head;
          do{
               temp = p->next;
               p->next = q;
               q = p;
               p = temp;
          }while(p!=head);

          temp = head;
          head = tail;
          tail = temp;
          
     }

     void printList(){
          if(head == NULL)
               return;
          else{
               CLLNode<T> * p = head;
               do{
                    cout<<p->info<<" ";
                    p = p->next;
               }while(p!=head);
          }
     }
};

int main(){
     CLList<int> * cll = new CLList<int>();
     cll->addAtHead(5);
     cout<<"\nList:";
     cll->printList();
     cll->addAtHead(7);
     cout<<"\nList:";
     cll->printList();
     cll->addAtHead(9);
     cout<<"\nList:";
     cll->printList();
     cll->addAtHead(3);
     cout<<"\nList:";
     cll->printList();
     cll->addAtHead(2);
     cout<<"\nList:";
     cll->printList();
     cll->reverse();
     cout<<"\nList:";
     cll->printList();
     if(cll->search(8)){
          cout<<"\nElement found";
     }
     else{
          cout<<"\nElement not found";
     }
}
