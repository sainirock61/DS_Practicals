#include<iostream>
using namespace std;
class CLLNode
{
public:
    int info;
    CLLNode *next; // this points to the address of the next node

    CLLNode()
    {
        info = 0;
        next = NULL;
    }

    CLLNode(int infoo)
    {
        info = infoo;
        next = NULL;
    }
};

class CLList
{
public:
    CLLNode *head;
    CLLNode *tail;

    CLList()
    {
        head = NULL;
        tail = NULL;
    }

void Traverse()
{
    CLLNode * p;
    p=head;
    do
    {
        cout<<p->info;
        p=p->next;
        cout<<endl;
    } while (p!=head);

    cout<<"\n Traversing done here . \n";
    
}

void Search(int key)
{
    CLLNode *p=head;
   
    do{
        if(p==NULL)
            return;
        if(p->info==key)
           return 1;
        
        p=p->next;
        
    } while(p->next!=head);

    return -1;
}
    
void AddAtHead(int value)
{
    CLLNode * p;
    CLLNode * N = new CLLNode(value);
    if(head == NULL)
    {
        head = N;
        head->next = head;
    }
    else
    {
        p=head;
        while(p->next!=head)
        {
            p=p->next;
        }

        p->next = N;
        N->next=head;
        N=head;
    }
    cout<<"\n Node Inserted : "<<value <<endl ;
    
}


void Add_at_nth_pos(int pos, int value)
{
    CLLNode *p;
    CLLNode *N = new CLLNode(value);
    if (pos==0)
    {
        if (head == NULL)
        {
            head = N;
            head->next = head;
        }
        else
        {
            p = head;
            while (p->next != head)
            {
                p = p->next;
            }

            p->next = N;
            N->next = head;
            N = head;
        }
    }	
    else
    {
        p = head;
        for (int i = 0; i < pos - 1; i++)
        {
            p = p->next;
        }
        N->next = p->next;
        p->next = N;
    }
    
    cout<<"\n Node inserted at index : "<<pos<<endl;
}

void DeleteAtHead()
{
    CLLNode *p;
    int x;
    p=head;
    while(p->next!=head) // since we have to change the next pointer of the last node pointing to new head, we need to traverse to the last node
    {
        p=p->next;
    }
    x=head->info;
    if(p==head) //same as if(head==tail)  only one node present
    {
        delete head;
        head=NULL;
    }
    else
    {
        p->next=head->next;
        delete head;
        head=p->next;
    }

    cout<<"\n Node Deleted : "<<x<<endl;
    
}

void Delete_at_nth_pos(int pos)
{
    CLLNode *p,*q;
    int x;
     if(pos==1)
    {
        p = head;
        while (p->next != head) // since we have to change the next pointer of the last node pointing to new head, we need to traverse to the last node
        {
            p = p->next;
        }
        x = head->info;
        if (p == head)
        {
            delete head;
            head = NULL;
        }
        else
        {
            p->next = head->next;
            delete head;
            head = p->next;
        }
    }
    else
    {
    p=head;
    for (int i = 0; i < pos - 2; i++)
    {
         p = p->next;
    }
        q = p->next;
        x = q->info;
        if(p)
        {
            p->next=p->next->next;
        }
        else
        {
            p->next=head;
        }
        
        delete q;

        
    }
    cout << "\n Node Deleted : " << x << endl;
}



};
int main()
{
    CLList l;
    l.AddAtHead(23);
    l.AddAtHead(45);
    l.AddAtHead(56);
    l.Add_at_nth_pos(0,89);
    l.AddAtHead(58);
   int search;
   search= l.Search(45);
   if(search ==1)
            cout<<"found";
    else
    {
            cout<<"not found";
    }
    
    l.Search(10);
    //l.DeleteAtHead();
    //l.Delete_at_nth_pos(4);
    l.Traverse();
return 0;

}
