#include<iostream>
using namespace std;
class Node
{
public:
    int info;
    Node *next; 

    Node()
    {
        info = 0;
        next = NULL;
    }

    Node(int value)
    {
        info = value;
        next = NULL;
    }
};

class Stack
{
public:
    Node *head;
    Node *tail;

    Stack()
    {
        head = NULL;
        tail = NULL;
    }
void push(int value) //Add at Tail
{
    Node *t = new Node(value);
    if(t==NULL)
        cout<<"\n Stack is Empty";

    if(head==NULL)
        head=tail=t;
    else
    {
        Node *temp = tail;
        temp->next = t;
        tail = t;
    }
    
}

void pop() //Delete at tail
{
    Node *temp = head;
    if (tail == NULL)
        cout << "\n Stack is Empty ";
    else if (head == tail)
    {
        delete head;
        delete tail;
        head = NULL;
    }
    else
    {
        while (temp->next != tail)
            temp = temp->next;
        tail = temp;
        tail->next = NULL;
        temp = temp->next;

        delete temp;

    }
    
    
}

void Display()
{
    Node *p = head;
    while (p)
    {
        cout << p->info << " ";
        p = p->next;
    }
}
};


int main()
{
    int choice, info;
    int pos;
    int size;
    char ch;
    Stack s;
    do
    {
        cout << "\n \t\t\t\t Welcome to Stack as a Linked list Menu ";
        cout << "\n 1. Adding node  \n 2. Deleting Node \n 3. Traversing the stack \n ";
        cout << "\n Enter your choice : ";
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            cout << "\n \t\t\t\t\t Adding Node ";

            cout << "\n Enter the node info you want to insert in Stack : ";
            cin >> info;
            s.push(info);
        }
        break;

        case 2:
        {
            cout << "\n \t\t\t\t\t  Deleting Node";
            s.pop();
        }
        break;

        case 3:
        {
            cout << "\n \t\t\t\t Traversing the Stack \n";
            s.Display();
        }

        break;

        default:
            cout << "\n Wrong choice entered";
        }

        cout << "\n Do you want to continue(Y/y or N/n) : ";
        cin >> ch;
    } while (ch == 'Y' || ch == 'y');

    return 0;
}