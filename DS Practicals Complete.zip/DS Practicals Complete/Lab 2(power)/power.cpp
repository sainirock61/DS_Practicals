#include<iostream>
using namespace std;

int power(int m, int n)
{
    if(n==0)
        return 1;
    else
        return power(m, n-1)*m;
}

int main()
{
    int num,pow;
    cout<<"\n Enter the number : ";
    cin>>num;
    cout<<"\n Enter the power : ";
    cin>>pow;
    int result;
    result = power(num,pow);
    cout<<"\n The answer is  : "<<result;

    return 0;
}