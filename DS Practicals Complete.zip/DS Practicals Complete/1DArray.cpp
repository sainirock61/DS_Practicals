#include<iostream>
using namespace std;
int main()

{

int *ar=new int[10];
int i;
cout<<"\n Enter the array ";
for(i=0;i<10;i++)
{
cin>>*(ar+i);
}

cout<<endl;
cout<<" The input array is : ";
for(i=0;i<10;i++)
{
cout<<*(ar+i);
}

return 0;

}
